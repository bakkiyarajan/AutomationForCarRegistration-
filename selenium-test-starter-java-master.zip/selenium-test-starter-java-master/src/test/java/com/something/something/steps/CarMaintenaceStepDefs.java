package com.something.something.steps;

import com.something.something.pages.Page;
import com.something.something.utils.Driver;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java8.En;

public class CarMaintenaceStepDefs extends Driver implements En {

    private Page page = new Page();
    public CarMaintenaceStepDefs() {
        Given("user go to url (.*)$", (final String url) -> {
            page.getUrl(url);
        });

         When("user click the free car check button", () -> {
            page.registerNumberSelection();
         });

        Then("^user should check the car details with output files$", () -> {

        });


    }





}
