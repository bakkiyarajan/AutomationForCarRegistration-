package com.something.something.pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.something.something.utils.Driver;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLOutput;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.openqa.selenium.By.xpath;

public class Page extends Driver {


    public void getUrl(final String url) throws InterruptedException {
        driver.navigate().to(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public void registerNumberSelection() throws IOException, InterruptedException {
        String InputFilePath = System.getProperty("user.dir") + ("\\src\\test\\resources\\inputfile\\car_input.txt");
        String input = new String(Files.readAllBytes(Paths.get(InputFilePath)));
        String outFilePath = System.getProperty("user.dir") + ("\\src\\test\\resources\\inputfile\\car_output.txt");
        List<String> lines = Files.readAllLines(Paths.get(outFilePath), StandardCharsets.UTF_8);
        Pattern p = Pattern.compile("[A-Z]{2}[0-9]{2}[\\s]{0,1}[A-Z]{3}");
        Matcher m = p.matcher(input);
        Page page = new Page();
        while (m.find()) {
            page.openBrowser();
            page.getUrl("https://cartaxcheck.co.uk");
            String registrationNumber = m.group();
            driver.findElement(xpath("//*[@id=\"vrm-input\"]")).sendKeys(registrationNumber);
            driver.findElement(xpath("//*[@id=\"m\"]/div[2]/div/div/div/div/form/button")).click();
            String regNo = driver.findElement(xpath("//*[@id=\"m\"]/div[2]/div[4]/div[1]/div/span/div[2]/dl[1]/dd")).getText();
            String make = driver.findElement(xpath("//*[@id=\"m\"]/div[2]/div[4]/div[1]/div/span/div[2]/dl[2]/dd")).getText();
            String model = driver.findElement(xpath("//*[@id=\"m\"]/div[2]/div[4]/div[1]/div/span/div[2]/dl[3]/dd")).getText();
            String color = driver.findElement(xpath("//*[@id=\"m\"]/div[2]/div[4]/div[1]/div/span/div[2]/dl[4]/dd")).getText();
            String year = driver.findElement(xpath("//*[@id=\"m\"]/div[2]/div[4]/div[1]/div/span/div[2]/dl[5]/dd")).getText();
            String vehicleDetails = regNo + "," + make + "," + model + "," + color + "," + year;
            if(lines.contains(vehicleDetails)){
                System.out.println("Car details are available:"+vehicleDetails);
            }else{
                System.out.println("Car details are not available");
            }

            page.closeBrowser();
        }


    }


}





